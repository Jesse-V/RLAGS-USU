Yet Another Astro Cam App

see http://www.evolware.org/?tag=yaaca for more info and documentation

