#!/bin/bash
sudo cp /home/linaro/Rlags_project/scripts/sedi_camera/my_watch_file /home/my_watch
