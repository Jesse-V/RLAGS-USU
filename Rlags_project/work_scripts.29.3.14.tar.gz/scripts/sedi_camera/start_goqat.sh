#!/bin/bash
sudo xvfb-run GoQat &
