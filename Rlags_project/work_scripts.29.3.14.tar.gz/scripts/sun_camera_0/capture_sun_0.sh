#!/bin/bash
sudo /home/linaro/Rlags_project/scripts/sun_camera_0/get_sun_image
sudo /home/linaro/Rlags_project/scripts/sun_camera_0/rename_image.sh
sudo /home/linaro/Rlags_project/scripts/sun_camera_0/mov_to_drive.sh
