#!/bin/bash
sudo mv sun_cam_0.jpg sun_cam_0.`date +"%d.%H.%M.%S"`.jpg
exit
