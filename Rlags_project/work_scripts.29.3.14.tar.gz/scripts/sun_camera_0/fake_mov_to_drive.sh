#!/bin/bash
sudo cp sun_cam_0.* /media/ssd_0/
sudo mv sun_cam_0.* /media/ssd_1/
