#!/bin/bash
./accel > test.txt.`date +"%d.%H.%M.%S"` &

