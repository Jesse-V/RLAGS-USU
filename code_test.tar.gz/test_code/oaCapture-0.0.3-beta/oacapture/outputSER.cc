/*****************************************************************************
 *
 * outputSER.cc -- SER output class
 *
 * Copyright 2013,2014 James Fidell (james@openastroproject.org)
 *
 * License:
 *
 * This file is part of the Open Astro Project.
 *
 * The Open Astro Project is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * The Open Astro Project is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with the Open Astro Project.  If not, see
 * <http://www.gnu.org/licenses/>.
 *
 *****************************************************************************/

#include <unistd.h>
#include <errno.h>

extern "C" {
#include <oaSER.h>
};

#include "outputHandler.h"
#include "outputSER.h"
#include "config.h"
#include "state.h"


OutputSER::OutputSER ( int x, int y, int n, int d, int fmt ) :
    OutputHandler ( x, y, n, d )
{
  frameCount = 0;
  xSize = x;
  ySize = y;
  colourId = OA_SER_MONO;
  littleEndian = 0;
  pixelDepth = 8;
  switch ( fmt ) {
    case OA_PIX_FMT_GREY8:
      colourId = 0;
      break;
    case OA_PIX_FMT_GREY16LE:
      colourId = 0;
      littleEndian = 1;
      pixelDepth = 16;
      break;
    case OA_PIX_FMT_GREY16BE:
      colourId = 0;
      pixelDepth = 16;
      break;
    case OA_PIX_FMT_BGGR8:
      colourId = OA_SER_BAYER_BGGR;
      break;
    case OA_PIX_FMT_RGGB8:
      colourId = OA_SER_BAYER_RGGB;
      break;
    case OA_PIX_FMT_GRBG8:
      colourId = OA_SER_BAYER_GRBG;
      break;
    case OA_PIX_FMT_GBRG8:
      colourId = OA_SER_BAYER_GBRG;
      break;
  }
  fullSaveFilePath = "";
}


OutputSER::~OutputSER()
{
  // Probably nothing to do here for SER files
}


int
OutputSER::outputExists ( void )
{
  if ( fullSaveFilePath == "" ) {
    filenameRoot = getFilename();
    fullSaveFilePath = filenameRoot + ".ser";
  }

  // FIX ME -- what if this returns an error?
  return ( access ( fullSaveFilePath.toStdString().c_str(), F_OK )) ? 0 : 1;
}


int
OutputSER::outputWritable ( void )
{
  if ( fullSaveFilePath == "" ) {
    filenameRoot = getFilename();
    fullSaveFilePath = filenameRoot + ".ser";
  }

  // FIX ME -- what if this returns an error?
  return ( access ( fullSaveFilePath.toStdString().c_str(), W_OK )) ? 0 : 1;
}


int
OutputSER::openOutput ( void )
{
  oaSERHeader	header;

  header.LuID = 0;
  header.ColorID = colourId;
  header.LittleEndian = littleEndian;
  header.ImageWidth = xSize;
  header.ImageHeight = ySize;
  header.PixelDepth = pixelDepth;
  header.FrameCount = 0;
  ( void ) snprintf ( header.Observer, 40, "not recorded" );
  ( void ) snprintf ( header.Instrument, 40, "not recorded" );
  ( void ) snprintf ( header.Telescope, 40, "not recorded" );

  int		e;

  if ( fullSaveFilePath == "" ) {
    filenameRoot = getFilename();
    fullSaveFilePath = filenameRoot + ".ser";
  }

  if (( e = oaSEROpen ( fullSaveFilePath.toStdString().c_str(),
      &SERContext ))) {
    qWarning() << "open of " << fullSaveFilePath << " failed";
    return -1;
  }

  oaSERWriteHeader ( &SERContext, &header );
  return 0;
}


int
OutputSER::addFrame ( void* frame )
{
  int ret;

  ret = oaSERWriteFrame ( &SERContext, frame );
  if ( ret ) {
    qWarning() << "oaSERWriteFrame failed";
  }
  frameCount++;
  return ret;
}


void
OutputSER::closeOutput ( void )
{
  oaSERWriteTrailer ( &SERContext );
  oaSERClose ( &SERContext );
}
