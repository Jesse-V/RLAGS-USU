/*****************************************************************************
 *
 * generalSettings.cc -- class for general settings in the settings UI
 *
 * Copyright 2013,2014 James Fidell (james@openastroproject.org)
 *
 * License:
 *
 * This file is part of the Open Astro Project.
 *
 * The Open Astro Project is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * The Open Astro Project is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with the Open Astro Project.  If not, see
 * <http://www.gnu.org/licenses/>.
 *
 *****************************************************************************/

#include "generalSettings.h"

#include "config.h"
#include "state.h"


GeneralSettings::GeneralSettings ( QWidget* parent ) : QWidget ( parent )
{
  saveBox = new QCheckBox ( tr ( "Load and save settings automatically" ),
      this );
  saveBox->setChecked ( config.saveSettings );

  reticleButtons = new QButtonGroup ( this );
  circleButton = new QRadioButton ( tr ( "Use circular reticle" ));
  crossButton = new QRadioButton ( tr ( "Use cross reticle" ));
  tramlineButton = new QRadioButton ( tr ( "Use tramline reticle" ));
  circleButton->setChecked ( config.reticleStyle == RETICLE_CIRCLE ? 1 : 0 );
  crossButton->setChecked ( config.reticleStyle == RETICLE_CROSS ? 1 : 0 );
  tramlineButton->setChecked ( config.reticleStyle == RETICLE_TRAMLINES ?
      1 : 0 );
  reticleButtons->addButton ( circleButton );
  reticleButtons->addButton ( crossButton );
  reticleButtons->addButton ( tramlineButton );

  tempButtons = new QButtonGroup ( this );
  degCButton = new QRadioButton ( tr ( "Display temperatures in degrees C" ));
  degFButton = new QRadioButton ( tr ( "Display temperatures in degrees F" ));
  degCButton->setChecked ( config.tempsInC );
  degFButton->setChecked ( !config.tempsInC );
  tempButtons->addButton ( degCButton );
  tempButtons->addButton ( degFButton );

  saveCaptureSettings = new QCheckBox ( tr (
      "Write capture settings to file" ));
  saveCaptureSettings->setChecked ( config.saveCaptureSettings );

  box = new QVBoxLayout ( this );
  box->addWidget ( saveBox );
  box->addSpacing ( 15 );
  box->addWidget ( circleButton );
  box->addWidget ( crossButton );
  box->addWidget ( tramlineButton );
  box->addSpacing ( 15 );
  box->addWidget ( degCButton );
  box->addWidget ( degFButton );
  box->addSpacing ( 15 );
  box->addWidget ( saveCaptureSettings );
  box->addStretch ( 1 );
  setLayout ( box );

  connect ( saveBox, SIGNAL ( stateChanged ( int )), parent,
      SLOT ( dataChanged()));
  connect ( reticleButtons, SIGNAL ( buttonClicked ( int )), parent,
      SLOT ( dataChanged()));
  connect ( saveCaptureSettings, SIGNAL ( stateChanged ( int )), parent,
      SLOT ( dataChanged()));
}


GeneralSettings::~GeneralSettings()
{
  delete reticleButtons;
  delete circleButton;
  delete crossButton;
  delete tramlineButton;
  delete tempButtons;
  delete degCButton;
  delete degFButton;
  delete box;
  delete saveBox;
  delete saveCaptureSettings;
}


void
GeneralSettings::storeSettings ( void )
{
  config.saveSettings = saveBox->isChecked() ? 1 : 0;
  if ( circleButton->isChecked()) {
    config.reticleStyle = RETICLE_CIRCLE;
  }
  if ( crossButton->isChecked()) {
    config.reticleStyle = RETICLE_CROSS;
  }
  if ( tramlineButton->isChecked()) {
    config.reticleStyle = RETICLE_TRAMLINES;
  }
  config.tempsInC = degCButton->isChecked();
  state.mainWindow->resetTemperatureLabel();
  config.saveCaptureSettings = saveCaptureSettings->isChecked() ? 1 : 0;
}
