ASICamera.h is based on that supplied with the ZWO SDK for Linux, but
modified to allow it to compile and link using gcc.
