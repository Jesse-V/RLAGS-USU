/*****************************************************************************
 *
 * QHY5.c -- QHY5 camera interface
 *
 * Copyright 2013,2014 James Fidell (james@openastroproject.org)
 *
 * License:
 *
 * This file is part of the Open Astro Project.
 *
 * The Open Astro Project is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * The Open Astro Project is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with the Open Astro Project.  If not, see
 * <http://www.gnu.org/licenses/>.
 *
 *****************************************************************************/

#include <libusb-1.0/libusb.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "oacam.h"
#include "QHYoacam.h"
#include "QHY5.h"

#define	cameraState		camera->_qhy
#define CLEAR(x)		memset ( &(x), 0, sizeof ( x ))
#define STORE_WORD_BE(var,val)  *(var)=((val)>>8)&0xff;*((var)+1)=(val)&0xff

#define QHY5_SENSOR_WIDTH	1558
#define QHY5_SENSOR_HEIGHT	1048
#define QHY5_IMAGE_WIDTH	1280
#define QHY5_IMAGE_HEIGHT	1024
#define	QHY5_BUFFERS		5
#define VBLANK			26
#define DARK_WIDTH_X		20

#define BUFFER_SIZE		19
#define USB_TIMEOUT		500


static void     _clearCameraData ( oaCamera* );
static int      _setParameters ( oaCamera*, int, int, int );
static void     _startExposure ( oaCamera*, unsigned int );
static int      _readExposure ( oaCamera*, void*, unsigned int );
static void     _initFuncPointers ( oaCamera* );
static void*    _capture ( void* );
static void     _init ( oaCamera* );
static int      _usbControlMsg ( oaCamera*, uint8_t, uint8_t, uint16_t,
                    uint16_t, unsigned char*, uint16_t, unsigned int );
static int      _usbBulkTransfer ( oaCamera*, unsigned char, unsigned char*,
                    int, int*, unsigned int );

static int      setControl ( oaCamera*, int, int );
static int      hasFixedFrameSizes ( oaCamera* );
static int      getFramePixelFormat ( oaCamera* );
static int      getPixelFormatForBitDepth ( oaCamera*, int );
static int      has16Bit ( oaCamera* );
static int      hasBinning ( oaCamera* );
static int      hasRawMode ( oaCamera* );
static int      hasDemosaicMode ( oaCamera* );
static FRAMESIZE* getFrameSizes ( oaCamera* );
static int      hasFrameRateSupport ( oaCamera* );
static const char* getName ( oaCamera* );
static int      hasTemperature ( oaCamera* );
static int      isColour ( oaCamera* );
static void     reset ( oaCamera* );
static void     stop ( oaCamera* );
static int      start ( oaCamera*, START_PARMS* );
static void     getControlRange ( oaCamera*, int, int*, int*, int*, int* );
static void     startReadFrame ( oaCamera*, int );
static void     finishReadFrame ( oaCamera* );
static int      readFrame ( oaCamera*, void** );
static void     closeCamera ( oaCamera* );

/**
 * Initialise a given camera device
 */

int
_QHY5InitCamera ( oaCamera* camera )
{
  int i, j;

  CLEAR ( camera->controls );

  camera->controls [ OA_CTRL_GAIN ] = 1;
  cameraState.minGain = 1;
  cameraState.maxGain = 100; // I think
  cameraState.stepGain = 1;
  cameraState.defaultGain = 10; // completely arbitrary

  camera->controls [ OA_CTRL_EXPOSURE_ABSOLUTE ] = 1;
  cameraState.minAbsoluteExposure = 1;
  cameraState.maxAbsoluteExposure = 0xffff; // I made this up
  cameraState.stepAbsoluteExposure = 1;
  cameraState.defaultAbsoluteExposure = 10; // completely arbitrary

  cameraState.maxResolutionX = QHY5_IMAGE_WIDTH;
  cameraState.maxResolutionY = QHY5_IMAGE_HEIGHT;

  cameraState.videoRGB24 = cameraState.videoGrey16 = 0;
  cameraState.videoGrey = 1;
  cameraState.videoCurrent = OA_PIX_FMT_GREY8;

  cameraState.resolutions[0].x = cameraState.maxResolutionX;
  cameraState.resolutions[0].y = cameraState.maxResolutionY;
  cameraState.resolutions[1].x = 0;
  cameraState.resolutions[1].y = 0;

  cameraState.xSize = cameraState.maxResolutionX;
  cameraState.ySize = cameraState.maxResolutionY;

  cameraState.buffers = 0;
  cameraState.configuredBuffers = 0;

  _init ( camera );

  cameraState.imageBufferLength = cameraState.maxResolutionX *
      cameraState.maxResolutionY;
  cameraState.buffers = calloc ( QHY5_BUFFERS, sizeof ( struct QHYbuffer ));
  for ( i = 0; i < QHY5_BUFFERS; i++ ) {
    void* m = malloc ( cameraState.imageBufferLength );
    if ( m ) {
      cameraState.buffers[i].start = m;
      cameraState.configuredBuffers++;
    } else {
      fprintf ( stderr, "%s malloc failed\n", __FUNCTION__ );
      if ( i ) {
        for ( j = 0; i < i; j++ ) {
          free (( void* ) cameraState.buffers[j].start );
        }
      }
      free ( cameraState.xferBuffer );
      return 0;
    }
  }

  _initFuncPointers ( camera );

  return -1;
}


static int
_setParameters ( oaCamera* camera, int height, int gain, int firstCall )
{
  // Weirdness starts here.
  //
  // First, gain settings.  Gain may be set for individual colour planes
  // (not applicable for the mono QHY5, obviously) and globally, but the
  // settings aren't linear.  Everyone seems to go for a lookup table for
  // this, so I guess I'll follow suit.

  static const int gainLookup[] = {
      0x000,0x004,0x005,0x006,0x007,0x008,0x009,0x00A,0x00B,0x00C,0x00D,0x00E,
      0x00F,0x010,0x011,0x012,0x013,0x014,0x015,0x016,0x017,0x018,0x019,0x01A,
      0x01B,0x01C,0x01D,0x01E,0x01F,0x051,0x052,0x053,0x054,0x055,0x056,0x057,
      0x058,0x059,0x05A,0x05B,0x05C,0x05D,0x05E,0x05F,0x6CE,0x6CF,0x6D0,0x6D1,
      0x6D2,0x6D3,0x6D4,0x6D5,0x6D6,0x6D7,0x6D8,0x6D9,0x6DA,0x6DB,0x6DC,0x6DD,
      0x6DE,0x6DF,0x6E0,0x6E1,0x6E2,0x6E3,0x6E4,0x6E5,0x6E6,0x6E7,0x6FC,0x6FD,
      0x6FE,0x6FF
  };
  static const int gainTableSize = ( sizeof ( gainLookup ) / sizeof ( int ));

  unsigned int offset, frameSize, frameSizeMSW, frameSizeLSW;
  unsigned int greenGain, blueGain, redGain, globalGain;
  unsigned char regs[ BUFFER_SIZE ];

  if ( gain > gainTableSize ) {
    gain = gainTableSize - 1;
  }
  greenGain = blueGain = redGain = globalGain = gainLookup[ gain ];

  // height must be a multiple of 4
  height -= height % 4;
  // how far from the top edge of the sensor we start
  offset = ( QHY5_SENSOR_HEIGHT - height ) / 2;
  frameSize = ( QHY5_SENSOR_WIDTH * ( height + VBLANK ));
  frameSizeMSW = frameSize >> 16;
  frameSizeLSW = frameSize & 0xffff;

  // The registers we appear to have access to are:
  // 0x01 - first row to read
  // 0x02 - first column to read
  // 0x03 - how many rows to read (less one)
  // 0x04 - how many columns to read (less one)
  // 0x09 - how many rows to integrate (including vblank?)
  // 0x2b - green gain
  // 0x2c - blue gain
  // 0x2d - red gain
  // 0x2e - global gain

  STORE_WORD_BE ( regs, greenGain );        // MT9M001 register 0x2b
  STORE_WORD_BE ( regs + 2, blueGain );     // MT9M001 register 0x2c
  STORE_WORD_BE ( regs + 4, redGain );      // MT9M001 register 0x2d
  STORE_WORD_BE ( regs + 6, globalGain );   // MT9M001 register 0x2e
  STORE_WORD_BE ( regs + 8, offset );       // MT9M001 register 0x01
  STORE_WORD_BE ( regs + 10, 0 );           // MT9M001 register 0x02
  STORE_WORD_BE ( regs + 12, height - 1 );  // MT9M001 register 0x03
  STORE_WORD_BE ( regs + 14, 1313 );        // MT9M001 register 0x04 (why 1314?)
  STORE_WORD_BE ( regs + 16, height + VBLANK - 1 ); // MT9M001 register 0x09
  regs[18] = 0xcc; // Magic number!

  // Lots of magic numbers :(
  // FIX ME -- check for errors here?

  _usbControlMsg ( camera, 0x42, 0x13, frameSizeLSW, frameSizeMSW, regs,
      BUFFER_SIZE, USB_TIMEOUT );
  _usbControlMsg ( camera, 0x42, 0x14, 0x31a5, 0, 0, 0, USB_TIMEOUT );
  _usbControlMsg ( camera, 0x42, 0x16, firstCall ? 1 : 0, 0, 0, 0,
      USB_TIMEOUT );

  return ( height + VBLANK );
}


static int
_usbControlMsg ( oaCamera* camera, uint8_t reqType, uint8_t req,
    uint16_t value, uint16_t index, unsigned char* data, uint16_t length,
    unsigned int timeout )
{
  int ret;

  pthread_mutex_lock ( &cameraState.usbMutex );
  ret = libusb_control_transfer ( cameraState.usbHandle, reqType, req, value,
      index, data, length, timeout );
  pthread_mutex_unlock ( &cameraState.usbMutex );
  return ret;
}


static int
_usbBulkTransfer ( oaCamera* camera, unsigned char endpoint,
    unsigned char* data, int length, int* transferred, unsigned int timeout )
{
  int ret;

  pthread_mutex_lock ( &cameraState.usbMutex );
  ret = libusb_bulk_transfer ( cameraState.usbHandle, endpoint, data, length,
      transferred, timeout );
  pthread_mutex_unlock ( &cameraState.usbMutex );
  return ret;
}


static void
_startExposure ( oaCamera* camera, unsigned int exposureTime )
{
  usleep ( 20000 ); // FIX ME -- removing it causes breakage
  // FIX ME -- more magic numbers
  _usbControlMsg ( camera, 0xc2, 0x12, exposureTime & 0xffff,
      exposureTime >> 16, 0, 0, 2 );
}


static int
_readExposure ( oaCamera* camera, void* buffer, unsigned int readLength )
{
  int ret;
  unsigned int readSize;

  ret = _usbBulkTransfer ( camera, 0x82, buffer, readLength, &readSize, 20000 );
  if ( ret ) {
    return ret;
  }
  if ( readSize != readLength ) {
   return -1;
  }
  return 0;
}


static void
_initFuncPointers ( oaCamera* camera )
{
  camera->funcs.setControl = ( void* ) setControl;
/*
  camera->funcs.setROI = unimp;
  camera->funcs.setFrameInterval = unimp;
*/
  camera->funcs.start = ( void* ) start;
  camera->funcs.stop = ( void* ) stop;
  camera->funcs.reset = ( void* ) reset;
  camera->funcs.close = ( void* ) closeCamera;
/*
  camera->funcs.setBitDepth = unimp;
  camera->funcs.setRawMode = unimp;
*/
  camera->funcs.hasRawMode = ( void* ) hasRawMode;
  camera->funcs.hasDemosaicMode = ( void* ) hasDemosaicMode;
  camera->funcs.has16Bit = ( void* ) has16Bit;
  camera->funcs.hasBinning = ( void* ) hasBinning;
/*
  camera->funcs.hasControl = unimp;
*/
  camera->funcs.hasFixedFrameSizes = ( void* ) hasFixedFrameSizes;
  camera->funcs.hasFrameRateSupport = ( void* ) hasFrameRateSupport;
/*
  camera->funcs.hasFixedFrameRates = unimp;
  camera->funcs.hasStartRequiresROI = unimp;
*/
  camera->funcs.isColour = ( void* ) isColour;
  camera->funcs.hasTemperature = ( void* ) hasTemperature;
  camera->funcs.getControlRange = ( void* ) getControlRange;
  camera->funcs.getFrameSizes = ( void* ) getFrameSizes;
/*
  camera->funcs.getFrameRates = unimp;
*/
  camera->funcs.getName = ( void* ) getName;
  camera->funcs.getFramePixelFormat = ( void* ) getFramePixelFormat;
/*
  camera->funcs.getTemperature = unimp;
*/
  camera->funcs.getPixelFormatForBitDepth = ( void* ) getPixelFormatForBitDepth;
  camera->funcs.startReadFrame = ( void* ) startReadFrame;
  camera->funcs.readFrame = ( void* ) readFrame;
  camera->funcs.finishReadFrame = ( void* ) finishReadFrame;
}


static int
setControl ( oaCamera* camera, int control, int value )
{
  switch ( control ) {

    case OA_CTRL_GAIN:
      cameraState.currentGain = value;
      _setParameters ( camera, QHY5_IMAGE_HEIGHT, cameraState.currentGain, 0 );
      break;

    case OA_CTRL_EXPOSURE_ABSOLUTE:
      pthread_mutex_lock ( &cameraState.captureMutex );
      cameraState.currentExposure = value;
      pthread_mutex_unlock ( &cameraState.captureMutex );
      break;

    default:
      fprintf ( stderr, "QHY5: %s not yet implemented for control %d\n",
          __FUNCTION__, control );
      break;
  }
}


static int
hasFixedFrameSizes ( oaCamera* camera )
{
  return -1;
}


static int
getFramePixelFormat ( oaCamera* camera )
{
  return OA_PIX_FMT_GREY8;
}


static int
getPixelFormatForBitDepth ( oaCamera* camera, int depth )
{
  return OA_PIX_FMT_GREY8;
}


static int
has16Bit ( oaCamera* camera )
{
  return 0;
}


static int
hasBinning ( oaCamera* camera )
{
  return 0;
}


static int
hasRawMode ( oaCamera* camera )
{
  return 0;
}


static int
hasDemosaicMode ( oaCamera* camera )
{
  return 0;
}


static FRAMESIZE*
getFrameSizes ( oaCamera* camera )
{
  return cameraState.resolutions;
}


static int
hasFrameRateSupport ( oaCamera* camera )
{
  return 0;
}


static const char*
getName ( oaCamera* camera )
{
  return "QHY5";
}


static int
hasTemperature ( oaCamera* camera )
{
  return 0;
}


static int
isColour ( oaCamera* camera )
{
  return 0;
}


static void
reset ( oaCamera* camera )
{
  unsigned char data = 0;
  unsigned int xferred;

  stop ( camera );
  _usbBulkTransfer ( camera, 1, &data, 1, &xferred, 5000 );
  _init ( camera );
}


static void
stop ( oaCamera* camera )
{
  if ( !cameraState.captureThreadStarted ) {
    return;
  }

  pthread_mutex_lock ( &cameraState.captureMutex );
  cameraState.captureThreadExit = 1;
  pthread_mutex_unlock ( &cameraState.captureMutex );
  pthread_join ( cameraState.captureThread, 0 );
  cameraState.captureThreadStarted = 0;
}


static int
start ( oaCamera* camera, START_PARMS* params )
{
  cameraState.captureThreadStarted = 0;
  cameraState.captureThreadExit = 0;
  pthread_create ( &cameraState.captureThread, 0, &_capture, camera );
  cameraState.captureThreadStarted = 1;
  return 0;
}


static void*
_capture ( void* param )
{
  oaCamera*     camera = param;
  int           quitThread, nextBuffer, i, j, x, y;
  unsigned int  exposureTime;
  uint8_t*      s;
  uint8_t*      t;

  pthread_mutex_lock ( &cameraState.captureMutex );
  cameraState.haveDataToRead = 0;
  cameraState.nextBufferToRead = -1;
  pthread_mutex_unlock ( &cameraState.captureMutex );
  nextBuffer = 0;

  while ( 1 ) {
    pthread_mutex_lock ( &cameraState.captureMutex );
    quitThread = cameraState.captureThreadExit;
    if ( nextBuffer == cameraState.nextBufferToRead ) {
      nextBuffer = ( nextBuffer + 1 ) % cameraState.configuredBuffers;
    }
    exposureTime = cameraState.currentExposure;
    pthread_mutex_unlock ( &cameraState.captureMutex );
    if ( quitThread ) {
      break;
    }

    // FIX ME -- there's stuff to be done here to handle very short exposures
    // perhaps where a rolling shutter is used, and where USB transfer times
    // might come into play

    _startExposure ( camera, exposureTime );
    usleep ( exposureTime );
    _readExposure ( camera, cameraState.xferBuffer,
        cameraState.xferBufferLength );

    t = cameraState.buffers[ nextBuffer ].start;
    for ( y = 0; y < cameraState.ySize; y++ ) {
      s = cameraState.xferBuffer + DARK_WIDTH_X + y * QHY5_SENSOR_WIDTH;
      for ( x = 0; x < cameraState.xSize; x++ ) {
        *t++ = *s++;
      }
    }

    pthread_mutex_lock ( &cameraState.captureMutex );
    cameraState.nextBufferToRead = nextBuffer;
    cameraState.haveDataToRead = 1;
    pthread_cond_signal ( &cameraState.frameAvailable );
    pthread_mutex_unlock ( &cameraState.captureMutex );
    nextBuffer = ( nextBuffer + 1 ) % cameraState.configuredBuffers;
  }
  return 0;
}


static void
_init ( oaCamera* camera )
{
  cameraState.captureHeight = _setParameters ( camera, QHY5_IMAGE_HEIGHT,
      8, 1 );

  cameraState.xferBufferLength = cameraState.captureHeight * QHY5_SENSOR_WIDTH;
  if (!( cameraState.xferBuffer = malloc ( cameraState.xferBufferLength ))) {
    // FIX ME -- may need to do something about closing camera here?
    fprintf ( stderr, "malloc of transfer buffer failed in %s\n",
        __FUNCTION__ );
    return;
  }

  // Now we need to capture a single frame for some reason.

  cameraState.currentGain = cameraState.defaultGain;
  cameraState.currentExposure = cameraState.defaultAbsoluteExposure;
  // FIX ME -- check for errors here?
  _startExposure ( camera, cameraState.currentExposure );
  usleep ( cameraState.currentExposure );
  _readExposure ( camera, cameraState.xferBuffer,
      cameraState.xferBufferLength );
  cameraState.captureHeight = _setParameters ( camera, QHY5_IMAGE_HEIGHT,
      cameraState.currentGain, 0 );
}


static void
getControlRange ( oaCamera* camera, int control, int* min, int* max,
    int* step, int* def )
{
  switch ( control ) {

    case OA_CTRL_GAIN:
      *min = cameraState.minGain;
      *max = cameraState.maxGain;
      *step = cameraState.stepGain;
      *def = cameraState.defaultGain;
      break;

    case OA_CTRL_EXPOSURE_ABSOLUTE:
      *min = cameraState.minAbsoluteExposure;
      *max = cameraState.maxAbsoluteExposure;
      *step = cameraState.stepAbsoluteExposure;
      *def = cameraState.defaultAbsoluteExposure;
      break;

    default:
      fprintf ( stderr, "QHY5: %s not yet implemented for control %d\n",
          __FUNCTION__, control );
      break;
  }
}


static void
startReadFrame ( oaCamera* camera, int frameTime )
{
  cameraState.frameTime = frameTime;
  return;
}


static int
readFrame ( oaCamera* camera, void** buffer )
{
  int haveData = 0;
  int bufferToRead;
  struct timespec waitTime;

  pthread_mutex_lock ( &cameraState.captureMutex );
  waitTime.tv_sec = cameraState.frameTime / 1000;
  waitTime.tv_nsec = ( cameraState.frameTime - 1000 * waitTime.tv_sec ) *
      1000000;
  while ( !cameraState.haveDataToRead ) {
    pthread_cond_timedwait ( &cameraState.frameAvailable,
        &cameraState.captureMutex, &waitTime );
  }
  haveData = cameraState.haveDataToRead;
  bufferToRead = cameraState.nextBufferToRead;
  cameraState.haveDataToRead = 0;
  pthread_mutex_unlock ( &cameraState.captureMutex );

  *buffer = haveData ? cameraState.buffers[ bufferToRead ].start : 0;
  return ( haveData ? cameraState.imageBufferLength : 0 );
}


static void
finishReadFrame ( oaCamera* camera )
{
  return;
}


static void
closeCamera ( oaCamera* camera )
{
  libusb_release_interface ( cameraState.usbHandle, 0 );
  libusb_close ( cameraState.usbHandle );
  libusb_exit ( cameraState.usbContext );
}
