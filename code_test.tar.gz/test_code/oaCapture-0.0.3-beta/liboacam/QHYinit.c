/*****************************************************************************
 *
 * QHYinit.c -- Initialise QHY cameras
 *
 * Copyright 2013,2014 James Fidell (james@openastroproject.org)
 *
 * License:
 *
 * This file is part of the Open Astro Project.
 *
 * The Open Astro Project is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * The Open Astro Project is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with the Open Astro Project.  If not, see
 * <http://www.gnu.org/licenses/>.
 *
 *****************************************************************************/

#include <libusb-1.0/libusb.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "oacam.h"
#include "QHYoacam.h"
#include "QHY5.h"

#define	cameraState		camera->_qhy
#define CLEAR(x)		memset ( &(x), 0, sizeof ( x ))

static void _clearCameraData ( oaCamera* );
static void _unimplemented();


/**
 * Initialise a given camera device
 */

oaCamera*
oaQHYInitCamera ( oaDevice* device )
{
  oaCamera*				camera;
  int                   		e, i, j, n, matched, ret;
  int					deviceAddr, deviceBus, numUSBDevices;
  __u32                 		id;
  libusb_device**			devlist;
  libusb_device*			usbDevice;
  libusb_device_handle*			usbHandle = 0;
  struct libusb_device_descriptor	desc;


  if ( device->_devType != CAM_QHY5 ) {
    fprintf ( stderr, "Unsupported camera %s\n", device->deviceName );
    return 0;
  }

  if (!( camera = ( oaCamera* ) malloc ( sizeof ( oaCamera )))) {
    perror ( "malloc oaCamera failed" );
    // FIX ME -- set errno?
    return 0;
  }
  _clearCameraData ( camera );

  ( void ) strcpy ( camera->deviceName, device->deviceName );
  cameraState.initialised = 0;
  cameraState.index = -1;

  // FIX ME -- This is a bit ugly.  Much of it is repeated from the
  // getCameras function.  I should join the two together somehow.

  libusb_init ( &cameraState.usbContext );
  // libusb_set_debug ( cameraState.usbContext, LIBUSB_LOG_LEVEL_DEBUG );
  numUSBDevices = libusb_get_device_list ( cameraState.usbContext, &devlist );
  if ( numUSBDevices < 1 ) {
    libusb_free_device_list ( devlist, 1 );
    libusb_exit ( cameraState.usbContext );
    if ( numUSBDevices ) {
      fprintf ( stderr, "Can't see any USB devices now (list returns -1)\n" );
      free ( camera );
      return 0;
    }
    fprintf ( stderr, "Can't see any USB devices now\n" );
    free ( camera );
    return 0;
  }

  matched = 0;
  deviceAddr = device->_devIndex & 0xff;
  deviceBus = device->_devIndex >> 8;
  for ( i = 0; i < numUSBDevices && !matched; i++ ) {
    usbDevice = devlist[i];
    if ( LIBUSB_SUCCESS != libusb_get_device_descriptor ( usbDevice, &desc )) {
      libusb_free_device_list ( devlist, 1 );
      libusb_exit ( cameraState.usbContext );
      fprintf ( stderr, "get device descriptor failed\n" );
      free ( camera );
      return 0;
    }
    if ( desc.idVendor == cameraList[ device->_misc ].vendorId &&
        desc.idProduct == cameraList[ device->_misc ].productId &&
        libusb_get_bus_number ( usbDevice ) == deviceBus &&
        libusb_get_device_address ( usbDevice ) == deviceAddr ) {
      // this looks like the one!
      matched = 1;
      libusb_open ( usbDevice, &usbHandle );
    }
  }
  libusb_free_device_list ( devlist, 1 );
  if ( !matched ) {
    fprintf ( stderr, "No matching USB device found!\n" );
    libusb_exit ( cameraState.usbContext );
    free ( camera );
    return 0;
  }
  if ( !usbHandle ) {
    fprintf ( stderr, "Unable to open USB device!\n" );
    libusb_exit ( cameraState.usbContext );
    free ( camera );
    return 0;
  }

  if ( libusb_kernel_driver_active ( usbHandle, 0 )) {
      libusb_detach_kernel_driver( usbHandle, 0 );
  }

  if (( ret = libusb_set_configuration ( usbHandle, 1 ))) {
    fprintf ( stderr, "Can't get configuration for USB device! err = %d\n",
        ret );
    fprintf ( stderr, "Try unplugging and reconnecting the device?\n" );
    libusb_exit ( cameraState.usbContext );
    free ( camera );
    return 0;
  }
  if ( libusb_claim_interface ( usbHandle, 0 )) {
    fprintf ( stderr, "Unable to claim interface for USB device!\n" );
    libusb_exit ( cameraState.usbContext );
    free ( camera );
    return 0;
  }
  // FIX ME -- may not be required?
  if ( libusb_set_interface_alt_setting ( usbHandle, 0, 0 )) {
    fprintf ( stderr, "Unable to set alternate interface for USB device!\n" );
    libusb_exit ( cameraState.usbContext );
    free ( camera );
    return 0;
  }

  camera->interface = device->interface;
  cameraState.usbHandle = usbHandle;
  cameraState.index = device->_devIndex;
  cameraState.cameraType = device->_devType;

  cameraState.captureThreadStarted = 0;
  cameraState.captureThreadExit = 0;
  pthread_mutex_init ( &cameraState.captureMutex, 0 );
  pthread_mutex_init ( &cameraState.usbMutex, 0 );
  pthread_cond_init ( &cameraState.frameAvailable, 0 );

  switch ( cameraState.cameraType ) {
    case CAM_QHY5:
      ret = _QHY5InitCamera ( camera );
      break;
    default:
      fprintf ( stderr, "unsupported camera type\n" );
      libusb_exit ( cameraState.usbContext );
      free ( camera );
      ret = -1;
      break;
  }
  if ( !ret ) {
    free ( camera );
    camera = 0;
  }

  return camera;
}


static void
_clearCameraData ( oaCamera* camera )
{
  void* unimp = _unimplemented;

  // FIX ME -- add all the missing ones
  cameraState.initialised = 0;
  cameraState.index = 0;
  cameraState.fd = 0;
  cameraState.cameraType = 0;
  cameraState.usbHandle = 0;
  cameraState.frameTime = 0;
  cameraState.haveDataToRead = 0;
  cameraState.nextBufferToRead = -1;
  cameraState.exposureTime = 1;

  camera->funcs.setControl = unimp;
  camera->funcs.setROI = unimp;
  camera->funcs.setFrameInterval = unimp;
  camera->funcs.start = unimp;
  camera->funcs.stop = unimp;
  camera->funcs.reset = unimp;
  camera->funcs.setBitDepth = unimp;
  camera->funcs.setRawMode = unimp;
  camera->funcs.has16Bit = unimp;
  camera->funcs.hasBinning = unimp;
  camera->funcs.hasControl = unimp;
  camera->funcs.hasFixedFrameSizes = unimp;
  camera->funcs.hasFrameRateSupport = unimp;
  camera->funcs.hasFixedFrameRates = unimp;
  camera->funcs.hasStartRequiresROI = unimp;
  camera->funcs.isColour = unimp;
  camera->funcs.hasTemperature = unimp;
  camera->funcs.hasRawMode = unimp;
  camera->funcs.hasDemosaicMode = unimp;
  camera->funcs.getControlRange = unimp;
  camera->funcs.getFrameSizes = unimp;
  camera->funcs.getFrameRates = unimp;
  camera->funcs.getName = unimp;
  camera->funcs.getFramePixelFormat = unimp;
  camera->funcs.getTemperature = unimp;
  camera->funcs.getPixelFormatForBitDepth = unimp;
  camera->funcs.startReadFrame = unimp;
  camera->funcs.readFrame = unimp;
  camera->funcs.finishReadFrame = unimp;
}


static void
_unimplemented()
{
  fprintf ( stderr, "QHY function unimplemented\n" );
}
