/*****************************************************************************
 *
 * QHYstate.h -- QHY camera state header
 *
 * Copyright 2013,2014 James Fidell (james@openastroproject.org)
 *
 * License:
 *
 * This file is part of the Open Astro Project.
 *
 * The Open Astro Project is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * The Open Astro Project is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with the Open Astro Project.  If not, see
 * <http://www.gnu.org/licenses/>.
 *
 *****************************************************************************/

#ifndef OA_QHY_STATE_H
#define OA_QHY_STATE_H

#include <sys/types.h>
#include <libusb-1.0/libusb.h>
#include <pthread.h>

struct QHYbuffer {
  void   *start;
  size_t length;
};


typedef struct {
  int                   initialised;
  int                   fd;
  unsigned long         index;
  libusb_context*       usbContext;
  libusb_device_handle* usbHandle;
  int                   cameraType;
  unsigned int          minGain;
  unsigned int          maxGain;
  unsigned int          stepGain;
  unsigned int          defaultGain;
  unsigned int          minAbsoluteExposure;
  unsigned int          maxAbsoluteExposure;
  unsigned int          stepAbsoluteExposure;
  unsigned int          defaultAbsoluteExposure;
  // FIX ME -- ought to do this dynamically
  FRAMESIZE             resolutions[OA_MAX_RESOLUTIONS+1];
  int                   videoYUV420;
  int                   videoRGB24;
  int                   videoYUYV;
  int                   videoGrey16;
  int                   videoGrey;
  unsigned int          videoCurrent;
  int                   configuredBuffers;
  unsigned int          maxResolutionX;
  unsigned int          maxResolutionY;
  int                   xSize;
  int                   ySize;
  unsigned int          currentGain;
  unsigned int          currentExposure;
  unsigned int          xferBufferLength;
  unsigned int          captureHeight;
  struct QHYbuffer*     buffers;
  unsigned int          imageBufferLength;
  unsigned char*        xferBuffer;
  int                   captureThreadStarted;
  int                   captureThreadExit;
  unsigned int          frameTime;
  pthread_t             captureThread;
  pthread_mutex_t       captureMutex;
  pthread_mutex_t       usbMutex;
  pthread_cond_t        frameAvailable;
  int                   haveDataToRead;
  int                   nextBufferToRead;
  unsigned              exposureTime;
} QHY_STATE;

#endif	/* OA_QHY_STATE_H */
