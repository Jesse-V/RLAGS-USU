/*****************************************************************************
 *
 * getFeatures -- interface for camera feature enumeration functions
 *
 * Copyright 2013,2014 James Fidell (james@openastroproject.org)
 *
 * License:
 *
 * This file is part of the Open Astro Project.
 *
 * The Open Astro Project is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * The Open Astro Project is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with the Open Astro Project.  If not, see
 * <http://www.gnu.org/licenses/>.
 *
 *****************************************************************************/

#include <sys/types.h>
#include <strings.h>
#include <stdlib.h>
#include <stdio.h>

#include "oacam.h"
#include "V4L2oacam.h"
#include "PGRoacam.h"
#include "PWCoacam.h"
#include "ZWASIoacam.h"
#include "QHYoacam.h"

int
oaCameraHas16Bit ( oaCamera* camera )
{
  // fprintf ( stderr, "%s\n", __FUNCTION__ );
  // We could perhaps implement this at this level by setting a flag
  // in osCamera from the init functions

  switch ( camera->interface ) {
    case OA_IF_V4L2:    
      return oaV4L2CameraHas16Bit ( camera );
      break;
    case OA_IF_ZWASI:   
      return oaZWASICameraHas16Bit ( camera );
      break;
    case OA_IF_QHY:
      return ( *( camera->funcs.has16Bit ))( camera );
      break;
    case OA_IF_PGR:
    case OA_IF_PWC:
      fprintf ( stderr, "%s: camera %d not yet supported\n",  __FUNCTION__,
          camera->interface );
      break;
  } 
  return 0;
}


int
oaCameraHasBinning ( oaCamera* camera, int factor )
{
  // fprintf ( stderr, "%s\n", __FUNCTION__ );
  // We could perhaps implement this at this level by setting some config
  // in osCamera from the init functions

  switch ( camera->interface ) {
    case OA_IF_V4L2:    
      return oaV4L2CameraHasBinning ( camera, factor );
      break;
    case OA_IF_ZWASI:   
      return oaZWASICameraHasBinning ( camera, factor );
      break;
    case OA_IF_QHY:
      return ( *( camera->funcs.hasBinning ))( camera );
      break;
    case OA_IF_PGR:
    case OA_IF_PWC:
      fprintf ( stderr, "%s: camera %d not yet supported\n", __FUNCTION__,
          camera->interface );
      break;
  } 
  return 0;
}


int
oaCameraHasControl ( oaCamera* camera, int control )
{
  return camera->controls[ control ];
}


int
oaCameraHasFixedFrameSizes ( oaCamera* camera )
{
  // fprintf ( stderr, "%s\n", __FUNCTION__ );
  // FIX ME -- This flag should perhaps be pulled out of the camera-specific
  // data and into the generic area

  switch ( camera->interface ) {
    case OA_IF_V4L2:
      return oaV4L2CameraHasFixedFrameSizes ( camera );
      break;
    case OA_IF_ZWASI:
      return oaZWASICameraHasFixedFrameSizes ( camera );
      break;
    case OA_IF_QHY:
      return ( *( camera->funcs.hasFixedFrameSizes ))( camera );
      break;
    case OA_IF_PWC:
    case OA_IF_PGR:
      fprintf ( stderr, "%s: camera %d not yet supported\n", __FUNCTION__,
          camera->interface );
      break;
  }

  return 0;
}


int
oaCameraHasFrameRateSupport ( oaCamera* camera )
{
  // fprintf ( stderr, "%s\n", __FUNCTION__ );
  // FIX ME -- flag in config data?
  switch ( camera->interface ) {
    case OA_IF_V4L2:
      return oaV4L2CameraHasFrameRateSupport ( camera );
      break;
    case OA_IF_ZWASI:
      return oaZWASICameraHasFrameRateSupport ( camera );
      break;
    case OA_IF_QHY:
      return ( *( camera->funcs.hasFrameRateSupport ))( camera );
      break;
    case OA_IF_PGR:
    case OA_IF_PWC:
      fprintf ( stderr, "%s: camera %d not yet supported\n", __FUNCTION__,
          camera->interface );
      break;
  }

  return 0;
}


int
oaCameraHasFixedFrameRates ( oaCamera* camera, int resX, int resY )
{
  // fprintf ( stderr, "%s\n", __FUNCTION__ );
  switch ( camera->interface ) {
    case OA_IF_V4L2:
      return oaV4L2CameraHasFixedFrameRates ( camera, resX, resY );
      break;
    case OA_IF_PGR:
    case OA_IF_PWC:
    case OA_IF_QHY:
    case OA_IF_ZWASI:
      fprintf ( stderr, "%s: camera %d not yet supported\n", __FUNCTION__,
          camera->interface );
      break;
  }

  return 0;
}


int
oaCameraStartRequiresROI ( oaCamera* camera )
{
  // fprintf ( stderr, "%s\n", __FUNCTION__ );
  // FIX ME -- flag in config data?
  switch ( camera->interface ) {
    case OA_IF_V4L2:
      return oaV4L2CameraStartRequiresROI ( camera );
      break;
    case OA_IF_PGR:
    case OA_IF_PWC:
    case OA_IF_QHY:
    case OA_IF_ZWASI:
      fprintf ( stderr, "%s: camera %d not yet supported\n", __FUNCTION__,
          camera->interface );
      break;
  }

  return 0;
}


int
oaCameraIsColour ( oaCamera* camera )
{
  // fprintf ( stderr, "%s\n", __FUNCTION__ );
  // We could perhaps implement this at this level by setting some config
  // in osCamera from the init functions

  switch ( camera->interface ) {
    case OA_IF_V4L2:
      return oaV4L2CameraIsColour ( camera );
      break;
    case OA_IF_ZWASI:
      return oaZWASICameraIsColour ( camera );
      break;
    case OA_IF_QHY:
      return ( *( camera->funcs.isColour ))( camera );
      break;
    case OA_IF_PGR:
    case OA_IF_PWC:
      fprintf ( stderr, "%s: camera %d not yet supported\n", __FUNCTION__,
          camera->interface );
      break;
  }
  return 0;
}


int
oaCameraHasTemperature ( oaCamera* camera )
{
  // fprintf ( stderr, "%s\n", __FUNCTION__ );
  // We could perhaps implement this at this level by setting some config
  // in osCamera from the init functions

  switch ( camera->interface ) {
    case OA_IF_V4L2:
      return oaV4L2CameraHasTemperature ( camera );
      break;
    case OA_IF_ZWASI:
      return oaZWASICameraHasTemperature ( camera );
      break;
    case OA_IF_QHY:
      return ( *( camera->funcs.hasTemperature ))( camera );
      break;
    case OA_IF_PGR:
    case OA_IF_PWC:
      fprintf ( stderr, "%s: camera %d not yet supported\n", __FUNCTION__,
          camera->interface );
      break;
  }
  return 0;
}


int
oaCameraHasRawMode ( oaCamera* camera )
{
  // fprintf ( stderr, "%s\n", __FUNCTION__ );
  // We could perhaps implement this at this level by setting a flag
  // in osCamera from the init functions

  switch ( camera->interface ) {
    case OA_IF_V4L2:
      return oaV4L2CameraHasRawMode ( camera );
      break;
    case OA_IF_ZWASI:
      return oaZWASICameraHasRawMode ( camera );
      break;
    case OA_IF_QHY:
      return ( *( camera->funcs.hasRawMode ))( camera );
      break;
    case OA_IF_PGR:
    case OA_IF_PWC:
      fprintf ( stderr, "%s: camera %d not yet supported\n", __FUNCTION__,
          camera->interface );
      break;
  }
  return 0;
}


int
oaCameraHasDemosaicMode ( oaCamera* camera )
{
  // fprintf ( stderr, "%s\n", __FUNCTION__ );
  // We could perhaps implement this at this level by setting a flag
  // in osCamera from the init functions

  switch ( camera->interface ) {
    case OA_IF_V4L2:
      return oaV4L2CameraHasDemosaicMode ( camera );
      break;
    case OA_IF_ZWASI:
      return oaZWASICameraHasDemosaicMode ( camera );
      break;
    case OA_IF_QHY:
      return ( *( camera->funcs.hasDemosaicMode ))( camera );
      break;
    case OA_IF_PGR:
    case OA_IF_PWC:
      fprintf ( stderr, "%s: camera %d not yet supported\n", __FUNCTION__,
          camera->interface );
      break;
  }
  return 0;
}
