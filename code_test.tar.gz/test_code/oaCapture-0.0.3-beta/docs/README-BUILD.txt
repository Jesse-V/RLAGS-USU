To build the binaries a few prerequisites are required.

The binaries link against the ZWO ASI camera and ffmpeg libraries as
well as libusb1, libv4l and Qt4.  The latter two should be fairly easy
to find the development packages for in most distributions.  On Ubuntu,
Mint (and perhaps Debian) you probably need:

  libv4l-dev
  libqt4-dev
  libqt4-dev-bin
  qt4-dev-tools
  qt4-qmake
  libudev-dev

The build requires both gcc and g++.

The binaries link against ffmpeg-2.1.1.  I don't believe any earlier
(1.2, 2.0) releases will work because of the requirement for the
raw non-debayered format that only appears to exist in the v2.1 releases.
A separate library is built just for this project to prevent clashes with
any other installed software.

The QHY5 driver triggers problems with the libusb installation on many
recent releases of Ubuntu.  For this reason the build scripts create a
local build of 1.0.18 to link against.  If you don't need QHY5 support
then this probably isn't required.  You'll also need to install the
fxload packages for the QHY5 to work, and your user must be in the "users"
group for the device to be usable by a user other than root.

The ASI SDK library is also available from the ZWO website.

There are two scripts, bin/BUILD-PREREQ.sh and bin/INSTALL-PREREQ.sh (both
should be run from the top level directory) that will fetch and build
the ffmpeg and libusb binaries and fetch the ASI binaries, then install
them.

yasm is required for the ffmpeg build amongst other things.  Tweaking
may be necessary to get all the prerequisites installed.
