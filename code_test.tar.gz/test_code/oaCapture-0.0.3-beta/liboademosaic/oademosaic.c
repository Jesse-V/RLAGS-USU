/*****************************************************************************
 *
 * demosaic.c -- main demosaic library entrypoint
 *
 * Copyright 2013,2014 James Fidell (james@openastroproject.org)
 *
 * License:
 *
 * This file is part of the Open Astro Project.
 *
 * The Open Astro Project is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * The Open Astro Project is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with the Open Astro Project.  If not, see
 * <http://www.gnu.org/licenses/>.
 *
 *****************************************************************************/

#include "oademosaic.h"
#include "nearestNeighbour.h"
#include "bilinear.h"

int
oademosaic ( void* source, void* target, int xSize, int ySize, int bitDepth,
    int format, int method )
{
  switch ( method ) {
    case OA_DEMOSAIC_NEAREST_NEIGHBOUR:
      oadNearestNeighbour ( source, target, xSize, ySize, bitDepth, format );
      return 0;
    case OA_DEMOSAIC_BILINEAR:
      oadBilinear ( source, target, xSize, ySize, bitDepth, format );
      return 0;
    default:
      return -1;
  }
  return 0;
}
