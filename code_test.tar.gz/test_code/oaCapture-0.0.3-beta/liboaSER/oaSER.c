/*****************************************************************************
 *
 * oaser.c -- main SER library entrypoint
 *
 * Copyright 2013,2014 James Fidell (james@openastroproject.org)
 *
 * License:
 *
 * This file is part of the Open Astro Project.
 *
 * The Open Astro Project is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * The Open Astro Project is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with the Open Astro Project.  If not, see
 * <http://www.gnu.org/licenses/>.
 *
 *****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <time.h>
#include <sys/time.h>

#include "oaSER.h"


static void  _oaSERInitMicrosoftTimestamp();
static ulong _oaSERGetMicrosoftTimestamp ( int );
static void  _oaSER32BitToLittleEndian ( uint32_t, uint8_t* );
static void  _oaSER64BitToLittleEndian ( uint64_t, uint8_t* );
static void  _oaSERnToLittleEndian ( uint64_t, uint8_t*, uint8_t );

const ulong epochTicks          = 621355968000000000L;
const ulong ticksPerSecond      = 10000000L;
const ulong ticksPerMicrosecond = 10L;
static long _offsetFromGMT      = 0;

#define TIMESTAMP_BLOCK_COUNT 1024
#define FRAME_COUNT_POSN      38

int
oaSEROpen ( const char* filename, oaSERContext* context )
{
  int fd;

  if (( fd = creat ( filename, 0644 )) < 0 ) {
    return fd;
  }
  context->SERfd = fd;
  context->frames = 0;
  context->bufferSize = TIMESTAMP_BLOCK_COUNT * 8;
  if (!( context->timestampBuffer = malloc ( context->bufferSize ))) {
    return -1;
  }
  context->nextTimestamp = context->timestampBuffer;
  context->framesLeft = 1024;
  return 0;
}


int
oaSERWriteHeader ( oaSERContext* context, oaSERHeader* header )
{
  uint8_t buffer[OA_SER_MAX_STRING_LEN+1];
  unsigned long now;

  header->version = 2;
  context->frameSize = header->PixelDepth / 8 * header->ImageWidth *
      header->ImageHeight;

  ( void ) snprintf ( header->FileID, 15, "LUCAM-RECORDER" );
  if ( write ( context->SERfd, header->FileID, 14 ) != 14 ) {
    return -1;
  }

  _oaSER32BitToLittleEndian ( header->LuID, buffer );
  if ( write ( context->SERfd, buffer, 4 ) != 4 ) {
    return -1;
  }

  _oaSER32BitToLittleEndian ( header->ColorID, buffer );
  if ( write ( context->SERfd, buffer, 4 ) != 4 ) {
    return -1;
  }

  _oaSER32BitToLittleEndian ( header->LittleEndian, buffer );
  if ( write ( context->SERfd, buffer, 4 ) != 4 ) {
    return -1;
  }

  _oaSER32BitToLittleEndian ( header->ImageWidth, buffer );
  if ( write ( context->SERfd, buffer, 4 ) != 4 ) {
    return -1;
  }

  _oaSER32BitToLittleEndian ( header->ImageHeight, buffer );
  if ( write ( context->SERfd, buffer, 4 ) != 4 ) {
    return -1;
  }

  _oaSER32BitToLittleEndian ( header->PixelDepth, buffer );
  if ( write ( context->SERfd, buffer, 4 ) != 4 ) {
    return -1;
  }

  header->FrameCount = 0;
  _oaSER32BitToLittleEndian ( header->FrameCount, buffer );
  if ( write ( context->SERfd, buffer, 4 ) != 4 ) {
    return -1;
  }

  bzero ( buffer, OA_SER_MAX_STRING_LEN+1 );
  ( void ) snprintf ( buffer, OA_SER_MAX_STRING_LEN+1, "%s",
      header->Observer );
  if ( write ( context->SERfd, buffer, OA_SER_MAX_STRING_LEN ) !=
      OA_SER_MAX_STRING_LEN ) {
    return -1;
  }

  bzero ( buffer, OA_SER_MAX_STRING_LEN+1 );
  ( void ) snprintf ( buffer, OA_SER_MAX_STRING_LEN+1, "%s",
      header->Instrument );
  if ( write ( context->SERfd, buffer, OA_SER_MAX_STRING_LEN ) !=
      OA_SER_MAX_STRING_LEN ) {
    return -1;
  }

  bzero ( buffer, OA_SER_MAX_STRING_LEN+1 );
  ( void ) snprintf ( buffer, OA_SER_MAX_STRING_LEN+1, "%s",
      header->Telescope );
  if ( write ( context->SERfd, buffer, OA_SER_MAX_STRING_LEN ) !=
      OA_SER_MAX_STRING_LEN ) {
    return -1;
  }

  _oaSERInitMicrosoftTimestamp();
  now = _oaSERGetMicrosoftTimestamp(0);
  _oaSER64BitToLittleEndian ( now, buffer );
  if ( write ( context->SERfd, buffer, 8 ) != 8 ) {
    return -1;
  }

  now = _oaSERGetMicrosoftTimestamp(1);
  _oaSER64BitToLittleEndian ( now, buffer );
  if ( write ( context->SERfd, buffer, 8 ) != 8 ) {
    return -1;
  }

  return 0;
}


int
oaSERWriteFrame ( oaSERContext* context, void* frame )
{
  uint8_t buffer[8];

  ulong now = _oaSERGetMicrosoftTimestamp(0);
  _oaSER64BitToLittleEndian ( now, buffer );

  if ( write ( context->SERfd, frame, context->frameSize ) !=
      context->frameSize ) {
    return -1;
  }
  context->frames++;

  bcopy ( buffer, context->nextTimestamp, 8 );
  context->nextTimestamp++;
  if ( !--context->framesLeft ) {
    context->bufferSize += TIMESTAMP_BLOCK_COUNT * 8;
    if (!( context->timestampBuffer = realloc ( context->timestampBuffer,
        context->bufferSize ))) {
      return -1;
    }
    context->nextTimestamp = context->timestampBuffer + context->frames;
    context->framesLeft = TIMESTAMP_BLOCK_COUNT;
  }
  return 0;
}


int
oaSERWriteTrailer ( oaSERContext* context )
{
  uint32_t bufferSize;
  uint8_t  buffer[4];

  bufferSize = context->frames * 8;
  if ( write ( context->SERfd, context->timestampBuffer, bufferSize ) !=
      bufferSize ) {
    return -1;
  }
  if ( !lseek ( context->SERfd, FRAME_COUNT_POSN, SEEK_SET )) {
    return -1;
  }
  _oaSER32BitToLittleEndian ( context->frames, buffer );
  if ( write ( context->SERfd, buffer, 4 ) != 4 ) {
    return -1;
  }
  return 0;
}


int
oaSERClose ( oaSERContext* context )
{
  close ( context->SERfd );
  free ( context->timestampBuffer );
  context->SERfd = -1;
  context->timestampBuffer = 0;
  return 0;
}


static void
_oaSERInitMicrosoftTimestamp()
{
  struct tm      *tmp;
  time_t         now;

  now = time(0);
  tmp = localtime ( &now );
  _offsetFromGMT = tmp->tm_gmtoff * ticksPerSecond;
}


static ulong
_oaSERGetMicrosoftTimestamp ( int utc )
{
  uint64_t       stamp;
  struct timeval tv;

  gettimeofday ( &tv, 0 );
  stamp = tv.tv_sec * ticksPerSecond + tv.tv_usec * ticksPerMicrosecond +
      epochTicks;
  if ( !utc ) {
    stamp += _offsetFromGMT;
  }

  return stamp;
}


static void
_oaSER32BitToLittleEndian ( uint32_t val, uint8_t* buf )
{
  _oaSERnToLittleEndian ( val, buf, 4 );
}


static void
_oaSER64BitToLittleEndian ( uint64_t val, uint8_t* buf )
{
  _oaSERnToLittleEndian ( val, buf, 8 );
}


static void
_oaSERnToLittleEndian ( uint64_t val, uint8_t* buf, uint8_t len )
{
  while ( len-- > 0 ) {
    *buf++ = val & 0xff;
    val >>= 8;
  }
}
